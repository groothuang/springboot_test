package com.platform.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@Controller
@RequestMapping(value = "/test2")
class TestController2 {
    @RequestMapping(value = "/index")
    public String index() {
        return "test2/index";
    }
    @RequestMapping(value = "/buy_exit")
    public String buy_exit() {
        return "test2/buy_exit";
    }
    @RequestMapping(value = "/buy_list")
    public String buy_list() {
        return "test2/buy_list";
    }
    @RequestMapping(value = "/doc_manage")
    public String doc_manage() {
        return "test2/doc_manage";
    }
    @RequestMapping(value = "/domain_manage")
    public String domain_manage() {
        return "test2/domain_manage";
    }
    @RequestMapping(value = "/footer")
    public String footer() {
        return "test2/footer";
    }
    @RequestMapping(value = "/left")
    public String left() {
        return "test2/left";
    }
    @RequestMapping(value = "/main")
    public String home() {
        return "test2/main";
    }
    @RequestMapping(value = "/market_center")
    public String market_center() {
        return "test2/market_center";
    }
    @RequestMapping(value = "/order_all")
    public String order_all() {
        return "test2/order_all";
    }
    @RequestMapping(value = "/order_place")
    public String order_place() {
        return "test2/order_place";
    }
    @RequestMapping(value = "/order_set")
    public String order_set() {
        return "test2/order_set";
    }
    @RequestMapping(value = "/save_shoe")
    public String save_shoe() {
        return "test2/save_shoe";
    }
    @RequestMapping(value = "/shoe_add")
    public String shoe_add() {
        return "test2/shoe_add";
    }
    @RequestMapping(value = "/shoe_envenstory")
    public String shoe_envenstory() {
        return "test2/shoe_envenstory";
    }
    @RequestMapping(value = "/shoe_house")
    public String shoe_house() {
        return "test2/shoe_house";
    }
    @RequestMapping(value = "/shoe_libery")
    public String shoe_libery() {
        return "test2/shoe_libery";
    }
    @RequestMapping(value = "/shoe_recycle")
    public String shoe_recycle() {
        return "test2/shoe_recycle";
    }
    @RequestMapping(value = "/shoe_strage")
    public String shoe_strage() {
        return "test2/shoe_strage";
    }
    @RequestMapping(value = "/shoe_tail")
    public String shoe_tail() {
        return "test2/shoe_tail";
    }
    @RequestMapping(value = "/shoe_warging")
    public String shoe_warging() {
        return "test2/shoe_warging";
    }
    @RequestMapping(value = "/shop_dec")
    public String shop_dec() {
        return "test2/shop_dec";
    }
    @RequestMapping(value = "/top")
    public String top() {
        return "test2/top";
    }
}