package com.platform.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@Controller
@RequestMapping(value = "/test1")
class TestController1 {
    @RequestMapping(value = "/index")
    public String index() {
        return "test1/index";
    }
    @RequestMapping(value = "/login")
    public String login() {
        return "test1/login";
    }
    @RequestMapping(value = "/admin-add")
    public String admin_add() {
        return "test1/admin-add";
    }
    @RequestMapping(value = "/admin-cate")
    public String admin_cate() {
        return "test1/admin-cate";
    }
    @RequestMapping(value = "/admin-edit")
    public String admin_edit() {
        return "test1/admin-edit";
    }
    @RequestMapping(value = "/admin-list")
    public String admin_list() {
        return "test1/admin-list";
    }
    @RequestMapping(value = "/admin-role")
    public String admin_role() {
        return "test1/admin-role";
    }
    @RequestMapping(value = "/admin-rule")
    public String admin_rule() {
        return "test1/admin-rule";
    }
    @RequestMapping(value = "/echarts1")
    public String echarts1() {
        return "test1/echarts1";
    }
    @RequestMapping(value = "/echarts2")
    public String echarts2() {
        return "test1/echarts2";
    }
    @RequestMapping(value = "/echarts3")
    public String echarts3() {
        return "test1/echarts3";
    }
    @RequestMapping(value = "/echarts4")
    public String echarts4() {
        return "test1/echarts4";
    }
    @RequestMapping(value = "/echarts5")
    public String echarts5() {
        return "test1/echarts5";
    }
    @RequestMapping(value = "/echarts6")
    public String echarts6() {
        return "test1/echarts6";
    }
    @RequestMapping(value = "/echarts7")
    public String echarts7() {
        return "test1/echarts7";
    }
    @RequestMapping(value = "/echarts8")
    public String echarts8() {
        return "test1/echarts8";
    }
    @RequestMapping(value = "/member-add")
    public String member_add() {
        return "test1/member-add";
    }
    @RequestMapping(value = "/member-del")
    public String member_del() {
        return "test1/member-del";
    }
    @RequestMapping(value = "/member-edit")
    public String member_edit() {
        return "test1/member-edit";
    }
    @RequestMapping(value = "/member-password")
    public String member_password() {
        return "test1/member-password";
    }
    @RequestMapping(value = "/order-add")
    public String order_add() {
        return "test1/order-add";
    }
    @RequestMapping(value = "/order-list")
    public String order_list() {
        return "test1/order-list";
    }
    @RequestMapping(value = "/role-add")
    public String role_add() {
        return "test1/role-add";
    }
    @RequestMapping(value = "/welcome")
    public String welcome() {
        return "test1/welcome";
    }
}