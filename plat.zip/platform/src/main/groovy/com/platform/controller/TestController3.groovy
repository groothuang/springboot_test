package com.platform.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@Controller
@RequestMapping(value = "/test3")
class TestController3 {
    @RequestMapping(value = "/index")
    public String index() {
        return "test3/index";
    }
    @RequestMapping(value = "/login")
    public String login() {
        return "test3/login";
    }
    @RequestMapping(value = "/main")
    public String home() {
        return "test3/main";
    }
    @RequestMapping(value = "/aptitudeInfo")
    public String aptitudeInfo() {
        return "test3/aptitudeInfo";
    }
    @RequestMapping(value = "/communication")
    public String communication() {
        return "test3/communication";
    }
    @RequestMapping(value = "/loginCode")
    public String loginCode() {
        return "test3/loginCode";
    }
    @RequestMapping(value = "/loginInfo")
    public String loginInfo() {
        return "test3/loginInfo";
    }
    @RequestMapping(value = "/loginUser")
    public String loginUser() {
        return "test3/loginUser";
    }
    @RequestMapping(value = "/shopList")
    public String shopList() {
        return "test3/shopList";
    }
    @RequestMapping(value = "/userList")
    public String userList() {
        return "test3/userList";
    }
}