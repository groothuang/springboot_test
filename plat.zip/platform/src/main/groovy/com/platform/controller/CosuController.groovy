package com.platform.controller

import com.platform.bean.*
import com.platform.mapper.UserMapper
import com.platform.service.RecordService
import com.platform.service.TestService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.jdbc.core.RowMapper
import org.springframework.jdbc.datasource.DataSourceTransactionManager
import org.springframework.stereotype.Controller
import org.springframework.transaction.TransactionStatus
import org.springframework.transaction.support.TransactionCallbackWithoutResult
import org.springframework.transaction.support.TransactionTemplate
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile
import org.springframework.web.servlet.ModelAndView

import javax.servlet.http.HttpSession
import javax.validation.Valid
import java.sql.ResultSet
import java.sql.ResultSetMetaData
import java.sql.SQLException
import java.text.SimpleDateFormat

/**
 * Created by RENGA on 2/4/2019.
 */
@Controller
@RequestMapping(value = "/cosu")
class CosuController {

    @RequestMapping(value = "/index")
    public String index() {
        return "cosu/index";
    }

    @RequestMapping(value = "/new")
    public String view(){
        return "cosu/new";
    }

    @RequestMapping(value = "/admin")
    public String admin(){
        return "cosu/admin";
    }

    @RequestMapping(value = "/record")
    public String record() {
        return "cosu/record";
    }

    @PostMapping(value = "/record")
     doRecord(UserVo userVo,UserMapper userMapper) {
//        def path = "C:\\Users\\HUANGGR\\IdeaProjects\\demo\\src\\main\\resources\\static\\record\\"
//        def recordData = [type:dataVo.type,msg_class: dataVo.msgClass,sender_id: dataVo.sender,receiver_id: dataVo.receiver,facility:dataVo.facility,vendor:dataVo.vendor]
//        def currentDate = new SimpleDateFormat("yyMMddHHmmss").format(new Date())
//        def currentDay = new SimpleDateFormat("yyMMdd").format(new Date())
//        RecordService rs = new RecordService();
//        if("D95B".equals(recordData.type)) {
//            rs.replaceModel("PP",recordData,path,currentDay,currentDate)
//            rs.replaceModel("PROD",recordData,path,currentDay,currentDate)
//        }else{
//            //交通部格式
//            rs.alterModel("CODECO",recordData,path,currentDay,currentDate)
//            rs.alterModel("COARRI",recordData,path,currentDay,currentDate)
//        }
        println(userVo.username+"  "+userMapper.getAll())
    }

    @RequestMapping(value = "/mytest")
    public String myTest(){
        return "cosu/mytest";
    }

    @PostMapping(value = "/mytest")
    doMyTest(TestVo testVo) {
        TestService rs = new TestService();

//        请给出一个高效的程序找出2个位置(开始和结束)，使从一个A[start]到A[end]的连续子序列之和绝对值最大，并返回这个值(最大值)。
//        例 A[5]={2,-1,4,-3,2};该数组最大和的子集合：起始位置为“0”，结束位置为“2” ，最大值为5，即“2+(-1)+4=5”
        String []b = testVo.num.toString().split(", ")
        int []num = new int[b.length]
        for (int i = 0; i < b.length; i++) {
             num[i] = Integer.parseInt(b[i]);
        }
        println("序列："+num.toString())
        rs.getMax(num)


        println("排序前:"+num.toString())
//        快速排序
        rs.sort(num, 0, num.length - 1);
//        冒泡排序
//        rs.bubbleSort(num)
        println("排序后:"+num.toString());

//        汉诺塔
        def pan = Integer.parseInt(testVo.pan)
        println("汉诺塔问题 移动"+pan+"个盘")
        rs.hanoi(pan,"A","B","C")

        def str = testVo.str
//        打印一个字符串的所有子字符串
        for (int i = 0; i < str.length(); i++) {
            for (int j = i; j <= str.length() ; j++) {
                print(" "+str.substring(i,j))
            }
        }
        println()
//        打印一个字符串的所有排列的子字符串
        rs.printAllSub(str,0,"")
    }
}
