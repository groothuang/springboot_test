package com.platform.bean

class TestVo {
    String num
    String pan
    String str
}
