package com.platform.service

import com.platform.bean.UserVo

public interface UserService {

    int addUser(UserVo user);

}
