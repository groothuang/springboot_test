package com.platform.service.impl

import com.platform.bean.UserVo
import com.platform.mapper.UserMapper
import com.platform.service.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

/**
 * Created by Administrator on 2017/8/16.
 */
@Service(value = "userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;//这里会报错，但是并不会影响

    @Override
    public int addUser(UserVo user) {

        return userMapper.insert(user);
    }
}