package com.platform.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@Controller
@RequestMapping(value = "/admin")
class AdminController {
    @RequestMapping(value = "/index")
    public String index() {
        return "admin/index";
    }
    @RequestMapping(value = "/login")
    public String login() {
        return "admin/login";
    }
    @RequestMapping(value = "/platform")
    public String platform() {
        return "admin/platform";
    }

    @RequestMapping(value = "/order")
    public String order() {
        return "admin/order";
    }

    @RequestMapping(value = "/leacots")
    public String leacots() {
        return "admin/leacots";
    }
}
