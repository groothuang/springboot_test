package com.platform.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@Controller
@RequestMapping(value = "/web")
class MainController {
    @RequestMapping(value = "/index")
    public String index() {
        return "web/index";
    }
    @RequestMapping(value = "/about")
    public String about() {
        return "web/about";
    }
    @RequestMapping(value = "/blog_category")
    public String category() {
        return "web/blog_category";
    }
    @RequestMapping(value = "/accessories")
    public String accessories() {
        return "web/accessories";
    }
    @RequestMapping(value = "/booking")
    public String booking() {
        return "web/booking";
    }
    @RequestMapping(value = "/login")
    public String login() {
        return "web/login";
    }
    @RequestMapping(value = "/register")
    public String register() {
        return "web/register";
    }
    @RequestMapping(value = "/contact")
    public String contact() {
        return "web/contact";
    }
    @RequestMapping(value = "/services")
    public String services() {
        return "web/services";
    }
    @RequestMapping(value = "/team")
    public String team() {
        return "web/team";
    }
    @RequestMapping(value = "/provide")
    public String provide() {
        return "web/provide";
    }
    @RequestMapping(value = "/detail")
    public String detail() {
        return "web/detail";
    }
    @RequestMapping(value = "/checkout")
    public String checkout() {
        return "web/checkout";
    }
    @RequestMapping(value = "/booking_done")
    public String done() {
        return "web/booking_done";
    }
    @RequestMapping(value = "/order")
    public String order() {
        return "web/order";
    }

}
