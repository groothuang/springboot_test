package com.platform.mapper

import com.platform.bean.UserVo

public interface UserMapper {

    int insert(UserVo record);

}
