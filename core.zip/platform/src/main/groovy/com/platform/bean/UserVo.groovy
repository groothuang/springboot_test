package com.platform.bean

import org.hibernate.validator.constraints.NotEmpty

import javax.validation.constraints.Size

/**
 * Created by RENGA on 2/11/2019.
 */
class UserVo {

    @NotEmpty(message="Cannot be empty!")
    String username

    @Size(min=6,max=10,message = "Password length size must be 6 to 10")
    String password
}
