package com.platform.bean

class DataVo {
    String type
    String msgClass
    String sender
    String receiver
    String facility
    String vendor
}
