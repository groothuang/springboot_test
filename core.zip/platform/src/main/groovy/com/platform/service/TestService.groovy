package com.platform.service

class TestService {
    static void getMax(a){
        int start, maxStart, maxEnd, sum, maxSum;
        start = maxStart = maxEnd = sum = maxSum = 0;
        //标记上一个值是否为负数
        boolean isFirst = false;

        for (int i = 0; i < a.length; i++)
        {
            //当前求和
            sum += a[i];

            //若小于0，跳过本次循环
            if (sum < 0)
            {
                //当前和清零
                sum = 0;
                //上一个值为负数
                isFirst = true;
                continue;
            }
            else
            {
                //上一个值为负数，则起始下标取当前值
                if(isFirst)
                {
                    start = i;
                    isFirst = false;
                }

                //若当前求和大于最大求和，记录最大和以及起始、结尾下标
                if (sum > maxSum)
                {
                    maxSum = sum;
                    maxStart = start;
                    maxEnd = i;
                }
            }
        }
        System.out.println("最大值之和："+maxSum);
        System.out.println("起始下标："+maxStart);
        System.out.println("终止下标："+maxEnd);
    }

    int step
    void hanoi(n,a,b,c){
        if(n==1){
            step++
            println ("第"+step+"步盘子从"+a+"移动到"+c)
        }else {
            hanoi(n-1,a,c,b)
            hanoi(1,a,b,c)
            hanoi(n-1,b,a,c)
        }

    }

    static void quickSort(int[] arr, int low, int high) {

        if (low < high) {
            // 找寻基准数据的正确索引
            int index = getIndex(arr, low, high);

            // 进行迭代对index之前和之后的数组进行相同的操作使整个数组变成有序
            quickSort(arr, 0, index - 1);
            quickSort(arr, index + 1, high);
        }

    }

    static int getIndex(int[] arr, int low, int high) {
        // 基准数据
        int tmp = arr[low];
        while (low < high) {
            // 当队尾的元素大于等于基准数据时,向前挪动high指针
            while (low < high && arr[high] >= tmp) {
                high--;
            }
            // 如果队尾元素小于tmp了,需要将其赋值给low
            arr[low] = arr[high];
            // 当队首元素小于等于tmp时,向后挪动low指针
            while (low < high && arr[low] <= tmp) {
                low++;
            }
            // 当队首元素大于tmp时,需要将其赋值给high
            arr[high] = arr[low];

        }
        // 跳出循环时low和high相等,此时的low或high就是tmp的正确索引位置
        // 由原理部分可以很清楚的知道low位置的值并不是tmp,所以需要将tmp赋值给arr[low]
        arr[low] = tmp;
        return low; // 返回tmp的正确位置
    }

    public void sort(int []arr,int low,int high)
    {
        int l=low;
        int h=high;
        int stand=arr[low];

        while(l<h)
        {
            while(l<h&&arr[h]>=stand)
                h--;
            if(l<h){
                int temp=arr[h];
                arr[h]=arr[l];
                arr[l]=temp;
                l++;
            }

            while(l<h&&arr[l]<=stand)
                l++;

            if(l<h){
                int temp=arr[h];
                arr[h]=arr[l];
                arr[l]=temp;
                h--;
            }
        }
        if(l-1>low) sort(arr,low,l-1);
        if(h+1<high) sort(arr,h+1,high);
    }

    def bubbleSort(int []arr){
        int i = arr.length-1
        int temp
        int pos = 0
        while (i>0){
            for (int j=0;j<i;j++){
                if (arr[j]>arr[j+1]){
                    pos=j
                    temp = arr[j]
                    arr[j]=arr[j+1]
                    arr[j+1]=temp
                }
            }
            i=pos
        }
        return arr
    }


    def printAllSub(def str, int i, def res)
    {
        if (i == str.length())
        {
            print(res+" ")
            return;
        }
        printAllSub(str, i + 1, res);         //不要
        printAllSub(str, i + 1, res + str[i]);//要
    }

}
