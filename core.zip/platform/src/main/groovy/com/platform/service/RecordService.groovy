package com.platform.service

class RecordService {
    //替换D95B模板
    public  static  void replaceModel(p,recordData,path,currentDay,currentDate){
        def recordpath = path + recordData.type + "\\" + recordData.msg_class+ "\\" + currentDay + "\\"
        File folder = new File(recordpath);
        if (!folder.exists() && !folder.isDirectory()) folder.mkdirs(); //判断存放sql文件夹的是否存在，若无则新建
        def name = (recordData.sender_id + "_" + recordData.receiver_id + "_" + recordData.msg_class + "_EDI" + "_" + currentDate + "_" + p).toUpperCase() + ".sql"
        File record = new File(recordpath + name);
        File model = new File(path + "model\\" + recordData.msg_class + "_" + p + ".sql");
        copyFile(model,record)
        replaceString(record, "<MESSAGE_CLASS>", recordData.msg_class);
        replaceString(record, "<RECEIVER_ID>", recordData.receiver_id);
        replaceString(record, "<SENDER_ID>", recordData.sender_id);
        replaceString(record, "<FACILITY_CODE>", recordData.facility);
        replaceString(record, "<VENDOR_CODE>", recordData.vendor);
    }

    //替换交通部格式模板
    public static void alterModel(mclass,recordData,path,currentDay,currentDate){
        def recordpath = path + "交通部格式\\" + currentDay + "\\"
        File folder = new File(recordpath);
        if (!folder.exists() && !folder.isDirectory()) folder.mkdirs();
        def name = (recordData.sender_id + "_" + recordData.receiver_id + "_" + mclass + "_" + currentDate).toUpperCase()

        File record1 = new File(recordpath + name + "_PP.sql");
        File model1 = new File(path + "model\\A_"+ mclass +"_PP.sql");
        copyFile(model1,record1)
        replaceString(record1, "<MESSAGE_CLASS>", mclass);
        replaceString(record1, "<RECEIVER_ID>", recordData.receiver_id);
        replaceString(record1, "<SENDER_ID>", recordData.sender_id);
        replaceString(record1, "<FACILITY_CODE>", recordData.facility);

        File record2 = new File(recordpath + name + "_PROD.sql");
        File model2 = new File(path + "model\\A_"+ mclass +"_PROD.sql");
        copyFile(model2,record2)
        replaceString(record2, "<MESSAGE_CLASS>", mclass);
        replaceString(record2, "<RECEIVER_ID>", recordData.receiver_id);
        replaceString(record2, "<SENDER_ID>", recordData.sender_id);
        replaceString(record2, "<FACILITY_CODE>", recordData.facility);

    }

    //复制模板
    public  static  void copyFile(File file,File file2){
        //指定读写格式
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "gbk"));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2), "utf-8"));
        try {
            String temp = null;
            while ((temp = br.readLine()) != null) {
                //每次写入一行.
                bw.write(temp);
                //并且进行换行
                bw.newLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            br.close();
            bw.close();
        }
    }

    //替换SQL中的字符串
    public static void replaceString(File file,String aStr,String bStr) throws Exception {

        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));

        //内存流
        CharArrayWriter caw = new CharArrayWriter();

        //替换
        String line = null;

        //以行为单位进行遍历
        while ((line = br.readLine()) != null) {
            //替换每一行中符合被替换字符条件的字符串
            line = line.replaceAll(aStr, bStr);
            //将该行写入内存
            caw.write(line);
            //添加换行符，并进入下次循环
            caw.append(System.getProperty("line.separator"));
        }
        //关闭输入流
        br.close();

        //将内存中的流写入源文件
        FileWriter fw = new FileWriter(file);
        caw.writeTo(fw);
        fw.close();
    }

//    //将字符串写在文件顶部
//    public static void appendFileHeader(byte[] header,String srcPath) throws Exception {
//        RandomAccessFile src = new RandomAccessFile(srcPath, "rw");
//        int srcLength = (int) src.length();
//        byte[] buff = new byte[srcLength];
//        src.read(buff, 0, srcLength);
//        src.seek(0);
//        src.write(header);
//        src.seek(header.length);
//        src.write(buff);
//        src.close();
//    }
//
//    //创建文件副本
//    public static void fileCopy(File source, File dest) throws IOException {
//        FileChannel inputChannel = null;
//        FileChannel outputChannel = null;
//        try {
//            inputChannel = new FileInputStream(source).getChannel();
//            outputChannel = new FileOutputStream(dest).getChannel();
//            outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
//        } finally {
//            inputChannel.close();
//            outputChannel.close();
//        }
//    }

}
